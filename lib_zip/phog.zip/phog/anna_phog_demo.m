I = 'image_0058.jpg';
bin = 8;
angle = 360;
L=3;
roi = [1;225;1;300];
p = anna_phog(I,bin,angle,L,roi)
